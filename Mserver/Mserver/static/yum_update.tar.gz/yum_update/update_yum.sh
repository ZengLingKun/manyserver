#!/bin/sh
ver=`cat /etc/redhat-release|grep release|awk '{print $7}'`
echo $ver

net_name=`grep ^e /proc/net/dev|cut -d: -f1`
if grep -i ^dns /etc/sysconfig/network-scripts/ifcfg-${net_name}
then 
echo 
else
echo "DNS1=10.95.18.13">>/etc/sysconfig/network-scripts/ifcfg-${net_name}
echo "DNS1=10.95.20.13">>/etc/sysconfig/network-scripts/ifcfg-${net_name}
systemctl restart network
fi


#if [ $ver -eq "7.3" ]; then
#	ehco $ver
#else
#	echo "$ver 版本暂不处理"
#fi
rpm -qa | grep yum | xargs rpm -e --nodeps
rpm -ivh wget-1.14-15.el7.x86_64.rpm
wget http://mirrors.163.com/centos/7/os/x86_64/Packages/rpm-4.11.3-25.el7.x86_64.rpm
rpm -Uvh rpm-4.11.3-25.el7.x86_64.rpm --nodeps
wget http://mirrors.163.com/centos/7/os/x86_64/Packages/yum-3.4.3-154.el7.centos.noarch.rpm
wget http://mirrors.163.com/centos/7/os/x86_64/Packages/yum-metadata-parser-1.1.4-10.el7.x86_64.rpm
wget http://mirrors.163.com/centos/7/os/x86_64/Packages/yum-plugin-fastestmirror-1.1.31-42.el7.noarch.rpm
rpm -ivh yum-*
cp ./CentOS-Base.repo /etc/yum.repos.d/
