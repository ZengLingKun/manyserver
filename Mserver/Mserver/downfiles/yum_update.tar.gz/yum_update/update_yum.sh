#!/bin/sh
ver=`cat /etc/redhat-release|grep release|awk '{print $7}'`
echo $ver

net_name=`grep '^ \?e' /proc/net/dev|cut -d: -f1`
if grep -i ^dns /etc/sysconfig/network-scripts/ifcfg-${net_name}
then 
echo 
else
echo "DNS1=10.95.18.13">>/etc/sysconfig/network-scripts/ifcfg-${net_name}
echo "DNS1=10.95.20.13">>/etc/sysconfig/network-scripts/ifcfg-${net_name}
systemctl restart network
fi


#if [ $ver -eq "7.3" ]; then
#	ehco $ver
#else
#	echo "$ver 版本暂不处理"
#fi
rpm -qa | grep yum | xargs rpm -e --nodeps
rpm -ivh wget-1.14-15.el7.x86_64.rpm
wget http://mirrors.163.com/centos/7/os/x86_64/Packages/ -O 163.txt
yum_=`grep -o '"yum-.\{5,7\}-.\{5,8\}.centos.noarch.rpm' 163.txt|cut -d\" -f2`
rpm_=` grep -o '"rpm-.\{6,13\}.x86_64.rpm' 163.txt |cut -d\" -f2`
yum_metadata_parser=`grep -o '"yum-metadata-parser-.\{10,25\}.rpm' 163.txt|cut -d\" -f2`
yum_plugin_fastestmirror=`grep -o '"yum-plugin-fastestmirror-.\{10,25\}.rpm' 163.txt|cut -d\" -f2`
wget http://mirrors.163.com/centos/7/os/x86_64/Packages/${rpm_}
rpm -Uvh ${rpm_} --nodeps
wget -O ${yum_} http://mirrors.163.com/centos/7/os/x86_64/Packages/${yum_}
wget -O ${yum_metadata_parser} http://mirrors.163.com/centos/7/os/x86_64/Packages/${yum_metadata_parser}
wget -O ${yum_plugin_fastestmirror} http://mirrors.163.com/centos/7/os/x86_64/Packages/${yum_plugin_fastestmirror}
rpm -ivh yum-*
cp ./CentOS-Base.repo /etc/yum.repos.d/
